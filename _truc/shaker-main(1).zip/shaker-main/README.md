
downlaod the project zip

# Installation setup

go to AssetLib -> import
![image](https://github.com/user-attachments/assets/aea0e528-5f28-454a-9761-e1b06c7a502e)  


ignore asset root  

![image](https://github.com/user-attachments/assets/c737d89a-1e4c-4018-8dd2-6abdab69be11)  

remove README.md  and shaker_example  
![image](https://github.com/user-attachments/assets/04fe9886-0d48-4292-9685-ab6e0f2b5a71)  


go in project_settings/plugins and enable Shaker

![image](https://github.com/user-attachments/assets/38abf623-38de-4ff9-9ec8-3eacac066412)
